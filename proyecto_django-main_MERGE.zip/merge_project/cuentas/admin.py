from django.contrib import admin

# Las cuentas de usuario usan el modelo estándar de Django (auth.User),
# que ya aparece en el panel de administración por defecto — no se
# necesita registrar nada adicional aquí por ahora.
