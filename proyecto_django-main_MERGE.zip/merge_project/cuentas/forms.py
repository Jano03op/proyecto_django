from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth.models import User
from django.db.models import Q
from django import forms


class LoginForm(AuthenticationForm):
    """Reutiliza la autenticación estándar de Django (valida usuario/clave
    contra la tabla auth_user), solo se le agregan clases de Bootstrap."""

    username = forms.CharField(
        label='Usuario',
        widget=forms.TextInput(attrs={'class': 'form-control', 'autofocus': True, 'placeholder': 'Nombre de usuario'})
    )
    password = forms.CharField(
        label='Contraseña',
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Contraseña'})
    )


class RegistroForm(UserCreationForm):
    """Registro de un nuevo usuario del sistema. Guarda directamente en la
    tabla auth_user (User.objects.create_user vía UserCreationForm.save())."""

    first_name = forms.CharField(
        label='Nombre', max_length=150, required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nombre'})
    )
    last_name = forms.CharField(
        label='Apellido', max_length=150, required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Apellido'})
    )
    email = forms.EmailField(
        label='Correo electrónico', required=True,
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'nombre@laserena.cl'})
    )

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('username', 'first_name', 'last_name', 'email')
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nombre de usuario'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['password1'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Contraseña'})
        self.fields['password2'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Repite la contraseña'})

    def clean_email(self):
        email = self.cleaned_data['email'].strip().lower()
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError('Ya existe una cuenta registrada con ese correo.')
        return email

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        if commit:
            user.save()
        return user


class BuscarUsuarioForm(forms.Form):
    """Paso 1 de recuperación de contraseña: identificar la cuenta por
    nombre de usuario o correo."""

    identificador = forms.CharField(
        label='Usuario o correo electrónico',
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Tu usuario o correo', 'autofocus': True})
    )

    def buscar_usuario(self):
        valor = self.cleaned_data['identificador'].strip()
        return User.objects.filter(
            Q(username__iexact=valor) | Q(email__iexact=valor)
        ).first()


class NuevaPasswordForm(forms.Form):
    """Paso 2 de recuperación de contraseña: define y guarda la nueva clave
    (User.set_password + user.save())."""

    password1 = forms.CharField(
        label='Nueva contraseña',
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Nueva contraseña'})
    )
    password2 = forms.CharField(
        label='Repite la nueva contraseña',
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Repite la nueva contraseña'})
    )

    def clean(self):
        cleaned = super().clean()
        p1, p2 = cleaned.get('password1'), cleaned.get('password2')
        if p1 and p2 and p1 != p2:
            raise forms.ValidationError('Las contraseñas no coinciden.')
        if p1 and len(p1) < 8:
            raise forms.ValidationError('La contraseña debe tener al menos 8 caracteres.')
        return cleaned
