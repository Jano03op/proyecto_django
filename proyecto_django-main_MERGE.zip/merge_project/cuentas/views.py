from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.models import User
from django.shortcuts import redirect, render

from .forms import BuscarUsuarioForm, LoginForm, NuevaPasswordForm, RegistroForm

REDIRECT_TRAS_LOGIN = 'organizacion:delegaciones_list'
SESSION_KEY_RECUPERAR = 'recuperar_user_id'


def login_view(request):
    """Autentica contra la tabla auth_user (Django) y abre sesión."""
    if request.user.is_authenticated:
        return redirect(REDIRECT_TRAS_LOGIN)

    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            messages.success(request, f'Bienvenido/a, {form.get_user().first_name or form.get_user().username}.')
            siguiente = request.GET.get('next')
            return redirect(siguiente or REDIRECT_TRAS_LOGIN)
    else:
        form = LoginForm(request)

    return render(request, 'cuentas/login.html', {'form': form})


def logout_view(request):
    """Cierra la sesión y redirige a la página pública."""
    logout(request)
    messages.info(request, 'Sesión cerrada correctamente.')
    return redirect('landing_page')


def registro_view(request):
    """Crea un usuario nuevo (guardado real en auth_user) e inicia sesión
    automáticamente al terminar."""
    if request.user.is_authenticated:
        return redirect(REDIRECT_TRAS_LOGIN)

    if request.method == 'POST':
        form = RegistroForm(request.POST)
        if form.is_valid():
            usuario = form.save()  # guarda el usuario en la base de datos
            login(request, usuario)
            messages.success(request, 'Cuenta creada correctamente. ¡Bienvenido/a al SGR!')
            return redirect(REDIRECT_TRAS_LOGIN)
    else:
        form = RegistroForm()

    return render(request, 'cuentas/registro.html', {'form': form})


def recuperar_view(request):
    """Recuperación de contraseña en dos pasos, sin depender de envío de
    correo (no hay backend de email configurado en el proyecto):

    Paso 1: el usuario se identifica por nombre de usuario o correo.
    Paso 2: define una nueva contraseña, que se guarda con set_password().

    El paso actual se controla con la sesión (SESSION_KEY_RECUPERAR), no
    con parámetros de la URL, para no exponer el id del usuario.
    """
    usuario_id = request.session.get(SESSION_KEY_RECUPERAR)

    # --- Paso 2: ya se identificó una cuenta, se define la nueva clave ---
    if usuario_id:
        try:
            usuario = User.objects.get(pk=usuario_id)
        except User.DoesNotExist:
            del request.session[SESSION_KEY_RECUPERAR]
            messages.error(request, 'La sesión de recuperación expiró. Intenta nuevamente.')
            return redirect('cuentas:recuperar')

        if request.method == 'POST':
            form_password = NuevaPasswordForm(request.POST)
            if form_password.is_valid():
                usuario.set_password(form_password.cleaned_data['password1'])
                usuario.save()  # guarda el nuevo hash de contraseña
                del request.session[SESSION_KEY_RECUPERAR]
                messages.success(request, 'Contraseña actualizada. Ya puedes iniciar sesión.')
                return redirect('cuentas:login')
        else:
            form_password = NuevaPasswordForm()

        return render(request, 'cuentas/recuperar_password.html', {
            'paso': 2,
            'usuario': usuario,
            'form_password': form_password,
        })

    # --- Paso 1: identificar la cuenta ---
    if request.method == 'POST':
        form_buscar = BuscarUsuarioForm(request.POST)
        if form_buscar.is_valid():
            usuario = form_buscar.buscar_usuario()
            if usuario:
                request.session[SESSION_KEY_RECUPERAR] = usuario.pk
                return redirect('cuentas:recuperar')
            messages.error(request, 'No encontramos ninguna cuenta con ese usuario o correo.')
    else:
        form_buscar = BuscarUsuarioForm()

    return render(request, 'cuentas/recuperar_password.html', {
        'paso': 1,
        'form_buscar': form_buscar,
    })
