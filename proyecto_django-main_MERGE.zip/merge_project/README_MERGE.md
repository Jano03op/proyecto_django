# Integración: base Django (proyecto_django-main) + diseño del módulo Delegaciones

## Resumen de la integración

Se mantienen sin modificaciones las siguientes partes del proyecto:

- `config/` (settings, urls, wsgi/asgi) — sin cambios de fondo. Se agregaron únicamente las líneas necesarias en `config/urls.py` para incluir las rutas de `cuentas` y `organizacion`, y las variables `LOGIN_URL`, `LOGIN_REDIRECT_URL`, `LOGOUT_REDIRECT_URL` en `settings.py`.
- `agenda/` — sin cambios (app sin modelos ni vistas implementadas aún).
- `indicadores/` — la vista, las urls y `datosarray.py` permanecen sin cambios. Se actualizó únicamente `templates/indicadores/dashboard.html` para que herede de la plantilla base compartida (`organizacion/base_app.html`), conforme al comentario `TODO` que ya existía en ese archivo. El contenido y la lógica del dashboard son los mismos.
- `templates/landing.html` — sin cambios de contenido. Se actualizaron los dos botones "Ingresar" (que apuntaban a `#`) para enlazar al listado de delegaciones.
- `requirements.txt`, `datosarray.py`, `importante.txt`, `db.sqlite3` — sin cambios.

Se implementó la app `organizacion` (previamente sin modelos ni vistas):

- `models.py`: `Delegacion`, `Cargo`, `Funcionario`.
- `forms.py`: formulario de delegación (nombre obligatorio, mínimo 4 caracteres).
- `views.py`: listado con búsqueda, filtro de estado y paginación; creación; edición; detalle (con funcionarios asociados); activación/desactivación.
- `urls.py`, `admin.py`: rutas y registro en el panel de administración.
- Plantillas: `base_app.html` (navbar con los menús Organización / Actividad / Medición), `delegacion_list.html`, `delegacion_form.html`, `delegacion_detail.html` — cubren las 5 pantallas del diseño de referencia (listado, creación, edición, detalle, modal de desactivación) con Bootstrap 5.

Se implementó la app `cuentas` (previamente sin modelos ni vistas), con persistencia sobre la tabla estándar `auth_user` de Django:

- **`login_view`** → `cuentas/login.html`. Autentica mediante `AuthenticationForm`; si es válido, abre sesión con `login()` y redirige a `organizacion:delegaciones_list` (o al parámetro `next`).
- **`logout_view`** → cierra sesión con `logout()` y redirige a `landing_page`.
- **`registro_view`** → `cuentas/registro.html`. Crea el usuario mediante `UserCreationForm` (nombre, apellido, usuario, correo, contraseña con confirmación) y abre sesión automáticamente tras el registro.
- **`recuperar_view`** → `cuentas/recuperar_password.html`. Flujo en dos pasos, sin dependencia de un backend de correo: 1) identificación de la cuenta por usuario o correo, 2) definición de nueva contraseña mediante `set_password()`. El paso activo se controla por sesión, no por parámetros de URL.

Rutas: `/cuentas/login/`, `/cuentas/logout/`, `/cuentas/registro/`, `/cuentas/recuperar/`.

Se agregó a `templates/organizacion/base_app.html` un menú de usuario (iniciales + "Cerrar sesión") visible cuando hay sesión activa, y un botón "Iniciar sesión" cuando no la hay.

## Paleta de colores

El diseño de referencia utilizaba azul marino (`#14213D`) como color primario. Se reemplazó por la paleta institucional ya definida en `landing.html`:

| Uso | Color en el diseño original | Color aplicado en la integración |
|---|---|---|
| Color primario / navbar | `#14213D` (navy) | `#7A1B1E` (granate) |
| Hover primario | `#1a2d54` | `#591314` (granate oscuro) |
| Fondo de página | `#f9fafb` (gray50) | `#F6F2EA` (crema) |
| Texto principal | `#111827` | `#1F2A33` (tinta) |
| Texto secundario | `#6b7280` | `#4A5560` (tinta suave) |
| Bordes | `#e5e7eb` | `#E2DACB` (línea) |
| Acento secundario (verificador) | azul claro | `#0E5C68` (azul costero) |

Se reutilizó también la tipografía de `landing.html` (Fraunces para títulos, Inter para el resto del contenido) para mantener una identidad visual única entre la página pública y el sistema interno.

## Módulos pendientes

Los ítems de menú "Funcionarios", "Actividades", "Agenda colectiva" y "Períodos" están marcados como "(próximamente)" y deshabilitados, dado que `agenda` y `cuentas` (en lo referente a roles) no tienen modelos ni lógica de negocio implementados aún. No se generaron datos ni comportamientos ficticios en esos módulos.

Las vistas de `organizacion` e `indicadores` no están protegidas con `@login_required`. La configuración (`LOGIN_URL`, `LOGIN_REDIRECT_URL`, `LOGOUT_REDIRECT_URL`) ya está lista en `settings.py` para aplicar esa protección cuando se decida requerir sesión iniciada en esos módulos.

## Nota de seguridad

El flujo de `recuperar_view` permite restablecer la contraseña conociendo únicamente el nombre de usuario o el correo asociado, sin verificación por correo electrónico ni token. Es funcional para un entorno académico o de pruebas, pero no es apto para producción: cualquier persona que conozca el usuario o correo de una cuenta podría restablecer su contraseña. Cuando el proyecto cuente con un backend de correo configurado, se recomienda migrar a `django.contrib.auth.views.PasswordResetView`, el mecanismo estándar de Django (con token firmado y envío de correo).

## Ejecución local

```bash
cd proyecto_django-main
python -m venv venv
source venv/bin/activate      # en Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py makemigrations organizacion
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Rutas de verificación:
- `http://127.0.0.1:8000/` — landing pública
- `http://127.0.0.1:8000/cuentas/login/` — inicio de sesión
- `http://127.0.0.1:8000/cuentas/registro/` — registro de cuenta
- `http://127.0.0.1:8000/organizacion/delegaciones/` — listado de delegaciones
- `http://127.0.0.1:8000/indicadores/progreso/` — dashboard existente, con el navbar compartido
- `http://127.0.0.1:8000/admin/` — panel de administración, para cargar Cargos, Delegaciones y Funcionarios de prueba

Nota: debe existir al menos un `Cargo` creado antes de registrar un `Funcionario`, dado que `Funcionario.cargo` es un campo obligatorio.
